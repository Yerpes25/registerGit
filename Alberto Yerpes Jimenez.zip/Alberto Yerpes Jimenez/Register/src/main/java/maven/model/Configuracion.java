/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maven.model;

/**
 *
 * @author Yerpeesss
 */
public class Configuracion {
    public static boolean esModoOscuro = false;
    public static double tamanoLetra = 13.0;  
    public static String tipoFuente = "System";
    public static String colorTemaHex = "#003F86";
    public static boolean sonidoActivo = false;
}
